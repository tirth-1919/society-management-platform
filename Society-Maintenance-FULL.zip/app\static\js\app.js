document.addEventListener('DOMContentLoaded', () => {
    // Theme toggle
    const themeBtn = document.getElementById('theme-toggle-btn');
    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }

    // Restore theme
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);

    // Active menu item auto-highlighting
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-nav .nav-item').forEach(item => {
        const href = item.getAttribute('href');
        if (href && href !== '#' && (currentPath === href || (href !== '/' && currentPath.startsWith(href)))) {
            document.querySelectorAll('.sidebar-nav .nav-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        }
    });

    // Show Ctrl+K desktop button
    if (window.innerWidth > 768) {
        const cmdBtn = document.getElementById('cmd-palette-btn');
        if (cmdBtn) cmdBtn.style.display = 'inline-flex';
    }
    const aiClose = document.getElementById('ai-chat-close');
    const aiSend = document.getElementById('ai-send-btn');
    const aiInput = document.getElementById('ai-input');
    const aiMessages = document.getElementById('ai-messages');

    function openAiBox() {
        aiBox.hidden = false;
        aiBox.style.display = 'flex';
        aiBtn.setAttribute('aria-expanded', 'true');
        aiInput.focus();
    }
    function closeAiBox() {
        aiBox.hidden = true;
        aiBox.style.display = 'none';
        aiBtn.setAttribute('aria-expanded', 'false');
        aiBtn.focus();
    }

    if (aiBtn && aiBox) {
        aiBtn.addEventListener('click', () => {
            if (aiBox.style.display === 'flex') closeAiBox(); else openAiBox();
        });
        if (aiClose) {
            aiClose.addEventListener('click', closeAiBox);
        }
        aiBox.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeAiBox();
        });
    }

    if (aiSend && aiInput && aiMessages) {
        const handleSend = async () => {
            const query = aiInput.value.trim();
            if (!query) return;

            // Render User Message
            const uMsg = document.createElement('div');
            uMsg.className = 'chat-msg user';
            uMsg.textContent = query;
            aiMessages.appendChild(uMsg);
            aiInput.value = '';
            aiMessages.scrollTop = aiMessages.scrollHeight;

            // Call AI Endpoint
            try {
                const response = await fetch('/api/v1/ai/query', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ prompt: query })
                });
                const data = await response.json();

                const bMsg = document.createElement('div');
                bMsg.className = 'chat-msg bot';
                bMsg.textContent = data.response || "No response received";
                aiMessages.appendChild(bMsg);
                aiMessages.scrollTop = aiMessages.scrollHeight;
            } catch (err) {
                console.error(err);
            }
        };

        aiSend.addEventListener('click', handleSend);
        aiInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handleSend();
        });
    }

    // Interactive Global Live Search
    const searchInput = document.getElementById('global-search-input');
    const searchDropdown = document.getElementById('search-results-dropdown');
    let searchDebounce = null;
    let lastQuery = '';

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>"']/g, (m) => {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
        });
    }

    function renderSearchResults(data, query) {
        if (!searchDropdown) return;
        searchDropdown.innerHTML = '';

        if (!data || !data.categories || data.categories.length === 0) {
            const noRes = document.createElement('div');
            noRes.className = 'search-no-results';
            const prefix = window.t ? window.t('no_results_found', 'No results found for') : 'No results found for';
            noRes.innerHTML = `${escapeHtml(prefix)} "<strong>${escapeHtml(query)}</strong>"`;
            searchDropdown.appendChild(noRes);
            searchDropdown.hidden = false;
            return;
        }

        data.categories.forEach(cat => {
            const header = document.createElement('div');
            header.className = 'search-category-header';
            header.setAttribute('data-i18n', cat.key);
            header.textContent = window.t ? window.t(cat.key, cat.key) : cat.key;
            searchDropdown.appendChild(header);

            cat.items.forEach(item => {
                const a = document.createElement('a');
                a.className = 'search-item';
                a.href = item.url || '#';
                a.innerHTML = `
                    <div class="search-item-icon"><i class="fa-solid ${escapeHtml(item.icon || 'fa-magnifying-glass')}"></i></div>
                    <div class="search-item-info">
                        <div class="search-item-title">${escapeHtml(item.title)}</div>
                        <div class="search-item-subtitle">${escapeHtml(item.subtitle)}</div>
                    </div>
                `;
                searchDropdown.appendChild(a);
            });
        });

        searchDropdown.hidden = false;
    }

    async function performSearch(query) {
        if (!query || query.trim().length < 2) {
            if (searchDropdown) searchDropdown.hidden = true;
            return;
        }

        lastQuery = query.trim();
        if (searchDropdown) {
            searchDropdown.hidden = false;
            const searchingTxt = window.t ? window.t('searching', 'Searching...') : 'Searching...';
            searchDropdown.innerHTML = `<div class="search-loading"><i class="fa-solid fa-spinner fa-spin"></i> ${escapeHtml(searchingTxt)}</div>`;
        }

        try {
            const response = await fetch(`/api/v1/search?q=${encodeURIComponent(lastQuery)}`, {
                credentials: 'include'
            });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();
            renderSearchResults(data, lastQuery);
        } catch (err) {
            console.error('Search error:', err);
            if (searchDropdown) {
                const errTxt = window.t ? window.t('error', 'Error searching') : 'Error searching';
                searchDropdown.innerHTML = `<div class="search-no-results">${escapeHtml(errTxt)}</div>`;
            }
        }
    }

    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const q = e.target.value;
            clearTimeout(searchDebounce);
            if (!q || q.trim().length < 2) {
                if (searchDropdown) searchDropdown.hidden = true;
                return;
            }
            searchDebounce = setTimeout(() => {
                performSearch(q);
            }, 300);
        });

        searchInput.addEventListener('focus', () => {
            if (searchInput.value && searchInput.value.trim().length >= 2) {
                performSearch(searchInput.value);
            }
        });

        document.addEventListener('click', (e) => {
            if (searchDropdown && !searchDropdown.contains(e.target) && e.target !== searchInput) {
                searchDropdown.hidden = true;
            }
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && searchDropdown) {
                searchDropdown.hidden = true;
            }
        });
    }

    document.addEventListener('languageChanged', () => {
        if (searchInput && searchInput.value && searchInput.value.trim().length >= 2) {
            performSearch(searchInput.value);
        }
    });

    // PWA Service Worker Registration
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/static/js/sw.js')
            .then(reg => console.log('PWA SW Registered', reg))
            .catch(err => console.error('PWA SW Error', err));
    }
});
