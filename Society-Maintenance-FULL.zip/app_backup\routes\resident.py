﻿"""Resident-only portal pages.

All records in this blueprint are derived from the authenticated resident,
never an identifier supplied by the browser.
"""

from app.utils import utcnow
from flask import (
    Blueprint,
    abort,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from sqlalchemy import or_

from app.models import (
    AuditLog,
    Document,
    MaintenanceBill,
    Notice,
    NotificationLog,
    NotificationPreference,
    Payment,
    PaymentReceipt,
    RegistrationRequest,
    Resident,
    Role,
    SupportRequest,
    User,
    db,
)

resident_bp = Blueprint("resident", __name__, url_prefix="/resident")


def _current_resident():
    user = db.session.get(User, session.get("user_id"))
    if not user or user.role != Role.RESIDENT or user.account_status != "ACTIVE":
        abort(403)
    resident = Resident.query.filter_by(
        user_id=user.id, society_id=user.society_id, is_primary=True
    ).first()
    if not resident:
        abort(403)
    return user, resident


@resident_bp.route("/profile", methods=["GET", "POST"])
def profile():
    user, resident = _current_resident()
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip() or None
        if not full_name:
            flash("Your full name is required.", "danger")
        elif (
            email and User.query.filter(User.email == email, User.id != user.id).first()
        ):
            flash("That email address is already in use.", "danger")
        else:
            user.full_name = resident.full_name = full_name
            user.email = resident.email = email
            db.session.add(
                AuditLog(
                    society_id=user.society_id,
                    user_id=user.id,
                    action="RESIDENT_PROFILE_UPDATED",
                    details="Resident updated permitted profile fields.",
                )
            )
            db.session.commit()
            flash("Your profile has been updated.", "success")
        return redirect(url_for("resident.profile"))
    approval = (
        RegistrationRequest.query.filter_by(user_id=user.id, status="APPROVED")
        .order_by(RegistrationRequest.approved_at.desc())
        .first()
    )
    return render_template(
        "resident/profile.html", user=user, resident=resident, approval=approval
    )


@resident_bp.route("/bills")
def bills():
    user, resident = _current_resident()
    query = MaintenanceBill.query.filter_by(
        society_id=user.society_id, resident_id=resident.id
    )
    search_term = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    month = request.args.get("month", "").strip()
    year = request.args.get("year", "").strip()
    if search_term:
        pattern = f"%{search_term}%"
        query = query.filter(
            or_(
                MaintenanceBill.bill_number.ilike(pattern),
                MaintenanceBill.billing_month.ilike(pattern),
            )
        )
    if status in {"Pending", "Partially Paid", "Paid", "Overdue"}:
        query = query.filter_by(status=status)
    if month and len(month) == 7:
        query = query.filter_by(billing_month=month)
    elif year.isdigit() and len(year) == 4:
        query = query.filter(MaintenanceBill.billing_month.like(f"{year}-%"))
    sort = request.args.get("sort", "month_desc")
    orderings = {
        "month_asc": MaintenanceBill.billing_month.asc(),
        "month_desc": MaintenanceBill.billing_month.desc(),
        "amount_desc": MaintenanceBill.total_amount.desc(),
        "amount_asc": MaintenanceBill.total_amount.asc(),
    }
    page = max(request.args.get("page", 1, type=int), 1)
    pagination = query.order_by(
        orderings.get(sort, MaintenanceBill.billing_month.desc())
    ).paginate(page=page, per_page=10, error_out=False)
    years = [
        value[0]
        for value in db.session.query(
            db.func.substr(MaintenanceBill.billing_month, 1, 4)
        )
        .filter_by(society_id=user.society_id, resident_id=resident.id)
        .distinct()
        .order_by(db.desc(db.func.substr(MaintenanceBill.billing_month, 1, 4)))
        .all()
    ]
    return render_template(
        "resident/bills.html",
        bills=pagination.items,
        pagination=pagination,
        years=years,
        filters={
            "q": search_term,
            "status": status,
            "month": month,
            "year": year,
            "sort": sort,
        },
    )


@resident_bp.route("/bills/<int:bill_id>")
def bill_detail(bill_id):
    user, resident = _current_resident()
    bill = MaintenanceBill.query.filter_by(
        id=bill_id, society_id=user.society_id, resident_id=resident.id
    ).first_or_404()
    latest_payment = (
        Payment.query.filter_by(
            bill_id=bill.id, resident_id=resident.id, society_id=user.society_id
        )
        .order_by(Payment.payment_date.desc())
        .first()
    )
    return render_template(
        "resident/bill_detail.html",
        bill=bill,
        resident=resident,
        latest_payment=latest_payment,
    )


@resident_bp.route("/security", methods=["POST"])
def change_password():
    user, _ = _current_resident()
    current_password = request.form.get("current_password", "")
    new_password = request.form.get("new_password", "")
    confirm_password = request.form.get("confirm_password", "")
    if not user.check_password(current_password):
        flash("Your current password is incorrect.", "danger")
    elif len(new_password) < 8:
        flash("Use a password with at least 8 characters.", "danger")
    elif new_password != confirm_password:
        flash("New password and confirmation do not match.", "danger")
    else:
        user.set_password(new_password)
        db.session.add(
            AuditLog(
                society_id=user.society_id,
                user_id=user.id,
                action="PASSWORD_CHANGED",
                details="Resident changed password.",
            )
        )
        db.session.commit()
        flash("Password updated successfully.", "success")
    return redirect(url_for("resident.profile"))


@resident_bp.route("/receipts")
def receipts():
    user, resident = _current_resident()
    query = PaymentReceipt.query.join(Payment).filter(
        Payment.society_id == user.society_id, Payment.resident_id == resident.id
    )
    search_term = request.args.get("q", "").strip()
    month = request.args.get("month", "").strip()
    year = request.args.get("year", "").strip()
    if search_term:
        pattern = f"%{search_term}%"
        query = query.filter(
            or_(
                PaymentReceipt.receipt_number.ilike(pattern),
                Payment.transaction_id.ilike(pattern),
            )
        )
    if month and len(month) == 7:
        query = query.filter(db.func.strftime("%Y-%m", Payment.payment_date) == month)
    elif year.isdigit() and len(year) == 4:
        query = query.filter(db.func.strftime("%Y", Payment.payment_date) == year)
    page = max(request.args.get("page", 1, type=int), 1)
    pagination = query.order_by(Payment.payment_date.desc()).paginate(
        page=page, per_page=10, error_out=False
    )
    years = [
        value[0]
        for value in db.session.query(db.func.strftime("%Y", Payment.payment_date))
        .join(PaymentReceipt, PaymentReceipt.payment_id == Payment.id)
        .filter(
            Payment.society_id == user.society_id, Payment.resident_id == resident.id
        )
        .distinct()
        .order_by(db.desc(db.func.strftime("%Y", Payment.payment_date)))
        .all()
    ]
    return render_template(
        "resident/receipts.html",
        receipts=pagination.items,
        pagination=pagination,
        years=years,
        filters={"q": search_term, "month": month, "year": year},
    )


NOTIFICATION_CATEGORIES = {
    "Maintenance": {
        "BILL_GENERATED",
        "DUE_REMINDER",
        "OVERDUE_REMINDER",
        "LATE_FEE_NOTICE",
    },
    "Payment": {"PAYMENT_SUCCESS"},
    "Account": set(),
    "System": set(),
}


def _notification_category(notification_type):
    for category, types in NOTIFICATION_CATEGORIES.items():
        if notification_type in types:
            return category
    return "System"


@resident_bp.route("/notifications")
def notifications():
    user, resident = _current_resident()
    category = request.args.get("category", "").strip()
    query = NotificationLog.query.filter_by(user_id=user.id, society_id=user.society_id)
    if category and category in NOTIFICATION_CATEGORIES:
        query = query.filter(
            NotificationLog.notification_type.in_(NOTIFICATION_CATEGORIES[category])
        )
    notifications = query.order_by(NotificationLog.created_at.desc()).all()

    # Deep-link target per notification: the bill for its billing_month
    # (Pay Now / View Bill) or the receipt for a payment confirmation
    # (View Receipt) â€” looked up read-only, scoped to this resident only.
    links = {}
    for item in notifications:
        if not item.billing_month:
            continue
        bill = MaintenanceBill.query.filter_by(
            society_id=user.society_id,
            resident_id=resident.id,
            billing_month=item.billing_month,
        ).first()
        if not bill:
            continue
        if item.notification_type == "PAYMENT_SUCCESS":
            payment = (
                Payment.query.filter_by(bill_id=bill.id, resident_id=resident.id)
                .order_by(Payment.payment_date.desc())
                .first()
            )
            if payment:
                links[item.id] = (
                    "View receipt",
                    url_for("payments.download_receipt", payment_id=payment.id),
                )
        elif bill.remaining_amount > 0:
            label = (
                "Pay now"
                if item.notification_type
                in {"DUE_REMINDER", "OVERDUE_REMINDER", "LATE_FEE_NOTICE"}
                else "View bill"
            )
            links[item.id] = (
                label,
                url_for("payments.pay_bill", bill_id=bill.id)
                if label == "Pay now"
                else url_for("resident.bill_detail", bill_id=bill.id),
            )

    return render_template(
        "resident/notifications.html",
        notifications=notifications,
        links=links,
        category=category,
        categories=list(NOTIFICATION_CATEGORIES.keys()),
        notification_category=_notification_category,
    )


@resident_bp.route("/notifications/<int:notification_id>/read", methods=["POST"])
def mark_notification_read(notification_id):
    user, _ = _current_resident()
    notification = NotificationLog.query.filter_by(
        id=notification_id, user_id=user.id, society_id=user.society_id
    ).first_or_404()
    if notification.read_at is None:
        notification.read_at = utcnow()
        db.session.commit()
    return redirect(url_for("resident.notifications"))


@resident_bp.route("/search")
def search():
    user, resident = _current_resident()
    term = request.args.get("q", "").strip()
    bills, payments, receipts = [], [], []
    if len(term) >= 2:
        pattern = f"%{term}%"
        bills = (
            MaintenanceBill.query.filter(
                MaintenanceBill.resident_id == resident.id,
                MaintenanceBill.society_id == user.society_id,
                or_(
                    MaintenanceBill.bill_number.ilike(pattern),
                    MaintenanceBill.billing_month.ilike(pattern),
                ),
            )
            .order_by(MaintenanceBill.billing_month.desc())
            .all()
        )
        payments = (
            Payment.query.filter(
                Payment.resident_id == resident.id,
                Payment.society_id == user.society_id,
                Payment.transaction_id.ilike(pattern),
            )
            .order_by(Payment.payment_date.desc())
            .all()
        )
        receipts = (
            PaymentReceipt.query.join(Payment)
            .filter(
                Payment.resident_id == resident.id,
                Payment.society_id == user.society_id,
                PaymentReceipt.receipt_number.ilike(pattern),
            )
            .all()
        )
    return render_template(
        "resident/search.html",
        term=term,
        bills=bills,
        payments=payments,
        receipts=receipts,
    )


@resident_bp.route("/help")
def help_center():
    user, _ = _current_resident()
    return render_template("resident/help.html", society=user.society)


@resident_bp.route("/announcements")
def announcements():
    user, _ = _current_resident()
    now = utcnow()
    notices = (
        Notice.query.filter(
            Notice.society_id == user.society_id,
            Notice.publish_date <= now,
            db.or_(Notice.expiry_date.is_(None), Notice.expiry_date >= now),
        )
        .order_by(Notice.publish_date.desc())
        .all()
    )
    return render_template("resident/announcements.html", notices=notices)


@resident_bp.route("/activity")
def activity():
    user, _ = _current_resident()
    # Read-only, strictly scoped to this authenticated user's own log
    # entries â€” never another resident's, regardless of any id in the URL.
    logs = (
        AuditLog.query.filter_by(user_id=user.id, society_id=user.society_id)
        .order_by(AuditLog.created_at.desc())
        .limit(100)
        .all()
    )
    return render_template("resident/activity.html", logs=logs)


@resident_bp.route("/payments/export.csv")
def export_payments_csv():
    import csv
    import io

    user, resident = _current_resident()
    payments = (
        Payment.query.filter_by(society_id=user.society_id, resident_id=resident.id)
        .order_by(Payment.payment_date.desc())
        .all()
    )
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(
        [
            "Date",
            "Bill Number",
            "Billing Month",
            "Amount Paid",
            "Method",
            "Transaction ID",
            "Status",
        ]
    )
    for p in payments:
        writer.writerow(
            [
                p.payment_date.strftime("%Y-%m-%d %H:%M") if p.payment_date else "",
                p.bill.bill_number if p.bill else "",
                p.bill.billing_month if p.bill else "",
                f"{p.amount_paid:.2f}",
                p.payment_method,
                p.transaction_id,
                p.status,
            ]
        )
    from flask import Response

    return Response(
        buf.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=my_payment_history.csv"},
    )


SUPPORT_CATEGORIES = ["Billing", "Payment", "Receipt", "Account", "Technical", "Other"]
SUPPORT_STATUSES = ["OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"]


@resident_bp.route("/support")
def support_list():
    user, resident = _current_resident()
    requests_list = (
        SupportRequest.query.filter_by(society_id=user.society_id, user_id=user.id)
        .order_by(SupportRequest.created_at.desc())
        .all()
    )
    return render_template("resident/support_list.html", requests=requests_list)


@resident_bp.route("/support/new", methods=["GET", "POST"])
def support_new():
    user, resident = _current_resident()
    if request.method == "POST":
        subject = (request.form.get("subject") or "").strip()
        category = request.form.get("category", "Other")
        message = (request.form.get("message") or "").strip()
        if category not in SUPPORT_CATEGORIES:
            category = "Other"
        if not subject or not message:
            flash("Subject and message are required.", "danger")
            return render_template(
                "resident/support_new.html",
                categories=SUPPORT_CATEGORIES,
                form={"subject": subject, "category": category, "message": message},
            )
        req = SupportRequest(
            society_id=user.society_id,
            user_id=user.id,
            resident_id=resident.id if resident else None,
            subject=subject,
            category=category,
            message=message,
            status="OPEN",
        )
        db.session.add(req)
        db.session.commit()
        flash(
            "Support request submitted. The society office will respond soon.",
            "success",
        )
        return redirect(url_for("resident.support_list"))
    return render_template(
        "resident/support_new.html", categories=SUPPORT_CATEGORIES, form={}
    )


@resident_bp.route("/support/<int:request_id>")
def support_detail(request_id):
    user, resident = _current_resident()
    # Ownership is enforced in the query itself, not checked afterward â€”
    # a request belonging to another resident simply doesn't match and
    # yields a 404, never a 403 that would confirm it exists.
    req = SupportRequest.query.filter_by(
        id=request_id, society_id=user.society_id, user_id=user.id
    ).first_or_404()
    return render_template("resident/support_detail.html", req=req)


@resident_bp.route("/preferences", methods=["GET", "POST"])
def notification_preferences():
    user, resident = _current_resident()
    pref = NotificationPreference.get_or_create(
        user.id, user.society_id, resident.id if resident else None
    )
    if request.method == "POST":
        pref.maintenance_reminders = "maintenance_reminders" in request.form
        pref.payment_reminders = "payment_reminders" in request.form
        pref.payment_confirmations = "payment_confirmations" in request.form
        pref.announcements = "announcements" in request.form
        db.session.commit()
        flash("Notification preferences updated.", "success")
        return redirect(url_for("resident.notification_preferences"))
    return render_template("resident/preferences.html", pref=pref)


@resident_bp.route("/documents")
def documents():
    user, _ = _current_resident()
    # Residents only ever see documents explicitly published to residents
    # in their own society â€” never ADMIN_ONLY/VENDOR_RESTRICTED documents,
    # and never another society's documents.
    docs = (
        Document.query.filter_by(
            society_id=user.society_id, access_level="RESIDENT_PUBLIC"
        )
        .order_by(Document.created_at.desc())
        .all()
    )
    return render_template("resident/documents.html", documents=docs)


@resident_bp.route("/documents/<int:doc_id>/download")
def download_document(doc_id):
    user, _ = _current_resident()
    doc = Document.query.filter_by(
        id=doc_id, society_id=user.society_id, access_level="RESIDENT_PUBLIC"
    ).first_or_404()
    from flask import send_file

    return send_file(doc.file_path, as_attachment=True)



