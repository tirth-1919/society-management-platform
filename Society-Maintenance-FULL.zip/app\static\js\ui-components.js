/**
 * Society SaaS - UI Components & Interactive Widgets (v2.0)
 * Reusable components for toasts, command palette, drawer, bulk actions, and keyboard shortcuts.
 */

'use strict';

// --------------------------------------------------------------------------
// 1. Toast Notification System
// --------------------------------------------------------------------------
window.toast = function(message, type = 'info', title = null) {
    let container = document.getElementById('global-toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'global-toast-container';
        container.className = 'toast-container';
        container.setAttribute('aria-live', 'polite');
        document.body.appendChild(container);
    }

    const toastItem = document.createElement('div');
    toastItem.className = `toast-item toast-${type}`;
    toastItem.setAttribute('role', 'alert');

    let iconClass = 'fa-circle-info';
    if (type === 'success') iconClass = 'fa-circle-check';
    else if (type === 'danger' || type === 'error') iconClass = 'fa-circle-exclamation';
    else if (type === 'warning') iconClass = 'fa-triangle-exclamation';

    const defaultTitle = type.charAt(0).toUpperCase() + type.slice(1);

    toastItem.innerHTML = `
        <i class="fa-solid ${iconClass} toast-icon" aria-hidden="true"></i>
        <div class="toast-content">
            <div class="toast-title">${escapeHTML(title || defaultTitle)}</div>
            <div class="toast-message">${escapeHTML(message)}</div>
        </div>
        <button type="button" class="toast-close" aria-label="Close notification"><i class="fa-solid fa-xmark"></i></button>
    `;

    const closeBtn = toastItem.querySelector('.toast-close');
    const dismiss = () => {
        toastItem.classList.add('toast-hiding');
        setTimeout(() => toastItem.remove(), 250);
    };

    closeBtn.addEventListener('click', dismiss);
    container.appendChild(toastItem);

    // Auto-dismiss after 4.5 seconds
    setTimeout(dismiss, 4500);
};

function escapeHTML(str) {
    if (!str) return '';
    return str.replace(/[&<>"']/g, m => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
    })[m]);
}

// --------------------------------------------------------------------------
// 2. Command Palette (Ctrl+K / Cmd+K)
// --------------------------------------------------------------------------
class CommandPalette {
    constructor() {
        this.backdrop = document.getElementById('cmd-palette-backdrop');
        this.input = document.getElementById('cmd-palette-input');
        this.resultsContainer = document.getElementById('cmd-palette-results');
        this.isOpen = false;
        this.selectedIndex = -1;
        this.items = [];

        if (this.backdrop && this.input) {
            this.init();
        }
    }

    init() {
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
                e.preventDefault();
                this.toggle();
            } else if (e.key === 'Escape' && this.isOpen) {
                this.close();
            } else if (this.isOpen) {
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    this.navigate(1);
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    this.navigate(-1);
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    this.triggerSelected();
                }
            }
        });

        this.backdrop.addEventListener('click', (e) => {
            if (e.target === this.backdrop) this.close();
        });

        this.input.addEventListener('input', () => {
            this.search(this.input.value.trim());
        });

        // Register default quick commands
        this.defaultCommands = [
            { title: 'Dashboard', subtitle: 'Go to main dashboard', icon: 'fa-chart-line', url: '/' },
            { title: 'My Bills', subtitle: 'View maintenance invoices', icon: 'fa-file-invoice', url: '/resident/bills' },
            { title: 'Pay Dues', subtitle: 'Pay outstanding maintenance bill', icon: 'fa-credit-card', url: '/resident/bills' },
            { title: 'Receipts', subtitle: 'Payment history & receipts', icon: 'fa-receipt', url: '/resident/receipts' },
            { title: 'Complaints', subtitle: 'Raise or view tickets', icon: 'fa-headset', url: '/complaints/' },
            { title: 'Notifications', subtitle: 'View society alerts', icon: 'fa-bell', url: '/resident/notifications' },
            { title: 'Toggle Theme', subtitle: 'Switch between light and dark mode', icon: 'fa-moon', action: () => {
                const btn = document.getElementById('theme-toggle-btn');
                if (btn) btn.click();
            }}
        ];
    }

    open() {
        this.isOpen = true;
        this.backdrop.classList.add('open');
        this.input.value = '';
        this.renderDefault();
        setTimeout(() => this.input.focus(), 50);
    }

    close() {
        this.isOpen = false;
        this.backdrop.classList.remove('open');
        this.selectedIndex = -1;
    }

    toggle() {
        if (this.isOpen) this.close();
        else this.open();
    }

    renderDefault() {
        this.items = this.defaultCommands;
        this.selectedIndex = 0;
        this.renderList('Quick Actions', this.items);
    }

    async search(query) {
        if (!query) {
            this.renderDefault();
            return;
        }

        try {
            const res = await fetch(`/api/v1/search?q=${encodeURIComponent(query)}`);
            const data = await res.json();
            const results = [];

            if (data && data.categories) {
                data.categories.forEach(cat => {
                    cat.items.forEach(item => {
                        results.push({
                            title: item.title,
                            subtitle: item.subtitle || cat.key,
                            icon: item.icon || 'fa-magnifying-glass',
                            url: item.url
                        });
                    });
                });
            }

            // Also search local default commands
            const matchedLocal = this.defaultCommands.filter(c => 
                c.title.toLowerCase().includes(query.toLowerCase()) || 
                c.subtitle.toLowerCase().includes(query.toLowerCase())
            );

            this.items = [...matchedLocal, ...results];
            this.selectedIndex = this.items.length > 0 ? 0 : -1;
            this.renderList(`Results for "${query}"`, this.items);
        } catch (err) {
            console.error('Command search failed', err);
        }
    }

    renderList(groupLabel, items) {
        this.resultsContainer.innerHTML = '';
        if (items.length === 0) {
            this.resultsContainer.innerHTML = '<div class="search-no-results">No matching actions found</div>';
            return;
        }

        const groupDiv = document.createElement('div');
        groupDiv.className = 'cmd-group-label';
        groupDiv.textContent = groupLabel;
        this.resultsContainer.appendChild(groupDiv);

        items.forEach((item, index) => {
            const el = document.createElement('div');
            el.className = `cmd-item ${index === this.selectedIndex ? 'selected' : ''}`;
            el.innerHTML = `
                <div class="cmd-item-icon"><i class="fa-solid ${item.icon}"></i></div>
                <div class="cmd-item-text">
                    <div>${escapeHTML(item.title)}</div>
                    <div style="font-size:11.5px; color:var(--text-secondary);">${escapeHTML(item.subtitle)}</div>
                </div>
            `;
            el.addEventListener('click', () => this.executeItem(item));
            this.resultsContainer.appendChild(el);
        });
    }

    navigate(dir) {
        if (this.items.length === 0) return;
        this.selectedIndex = (this.selectedIndex + dir + this.items.length) % this.items.length;
        const domItems = this.resultsContainer.querySelectorAll('.cmd-item');
        domItems.forEach((el, i) => {
            el.classList.toggle('selected', i === this.selectedIndex);
            if (i === this.selectedIndex) el.scrollIntoView({ block: 'nearest' });
        });
    }

    triggerSelected() {
        if (this.selectedIndex >= 0 && this.selectedIndex < this.items.length) {
            this.executeItem(this.items[this.selectedIndex]);
        }
    }

    executeItem(item) {
        this.close();
        if (item.action) {
            item.action();
        } else if (item.url) {
            window.location.href = item.url;
        }
    }
}

// --------------------------------------------------------------------------
// 3. Sidebar Collapsible & Mobile Drawer Controls
// --------------------------------------------------------------------------
function initSidebarControls() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleBtn = document.getElementById('sidebar-toggle-btn');
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const overlay = document.getElementById('sidebar-mobile-overlay');

    // Populate data-tooltips for collapsed state
    if (sidebar) {
        sidebar.querySelectorAll('.nav-item').forEach(item => {
            const span = item.querySelector('span');
            if (span && !item.getAttribute('data-tooltip')) {
                item.setAttribute('data-tooltip', span.textContent.trim());
            }
        });
    }

    // Restore desktop collapsed state
    const isCollapsed = localStorage.getItem('sidebar_collapsed') === 'true';
    if (isCollapsed && sidebar && mainContent && window.innerWidth > 768) {
        sidebar.classList.add('sidebar-collapsed');
        mainContent.classList.add('sidebar-collapsed-active');
    }

    if (toggleBtn && sidebar && mainContent) {
        toggleBtn.addEventListener('click', () => {
            const collapsed = sidebar.classList.toggle('sidebar-collapsed');
            mainContent.classList.toggle('sidebar-collapsed-active', collapsed);
            localStorage.setItem('sidebar_collapsed', collapsed ? 'true' : 'false');
        });
    }

    // Mobile drawer toggle
    if (mobileMenuBtn && sidebar && overlay) {
        mobileMenuBtn.addEventListener('click', () => {
            sidebar.classList.add('mobile-open');
            overlay.classList.add('active');
        });

        overlay.addEventListener('click', () => {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('active');
        });
    }
}

// --------------------------------------------------------------------------
// 4. Back To Top Button & Scroll Restoration
// --------------------------------------------------------------------------
function initBackToTop() {
    const btn = document.getElementById('back-to-top-btn');
    if (!btn) return;

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            btn.classList.add('visible');
        } else {
            btn.classList.remove('visible');
        }
    });

    btn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// --------------------------------------------------------------------------
// 5. Page Progress Bar on Navigation
// --------------------------------------------------------------------------
function initPageProgressBar() {
    const progressBar = document.getElementById('page-progress-bar');
    if (!progressBar) return;

    window.addEventListener('beforeunload', () => {
        progressBar.style.opacity = '1';
        progressBar.style.width = '70%';
    });
}

// --------------------------------------------------------------------------
// 6. Recently Visited Tracker
// --------------------------------------------------------------------------
function trackRecentlyVisited() {
    try {
        const title = document.title.replace('· Society SaaS', '').replace('- Society SaaS', '').trim();
        const path = window.location.pathname;
        if (path === '/login' || path === '/register' || path === '/logout') return;

        let recent = JSON.parse(localStorage.getItem('recently_visited') || '[]');
        recent = recent.filter(r => r.path !== path);
        recent.unshift({ title, path, time: Date.now() });
        recent = recent.slice(0, 8); // Keep top 8
        localStorage.setItem('recently_visited', JSON.stringify(recent));
    } catch (e) {
        // LocalStorage fallback
    }
}

// --------------------------------------------------------------------------
// 7. Global Keyboard Shortcuts (P=Pay, B=Bills, R=Receipts, /=Search)
// --------------------------------------------------------------------------
function initKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // Ignore if user is typing inside an input/textarea/select
        const activeTag = document.activeElement ? document.activeElement.tagName : '';
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(activeTag) || document.activeElement.isContentEditable) {
            return;
        }

        if (e.key === '/' && !e.ctrlKey && !e.metaKey) {
            e.preventDefault();
            const searchInput = document.getElementById('global-search-input');
            if (searchInput) searchInput.focus();
        } else if (e.key === 'b' || e.key === 'B') {
            const billLink = document.querySelector('a[href*="/resident/bills"]');
            if (billLink) window.location.href = billLink.href;
        } else if (e.key === 'r' || e.key === 'R') {
            const recLink = document.querySelector('a[href*="/resident/receipts"]');
            if (recLink) window.location.href = recLink.href;
        }
    });
}

// Auto-run on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
    window.cmdPalette = new CommandPalette();
    initSidebarControls();
    initBackToTop();
    initPageProgressBar();
    trackRecentlyVisited();
    initKeyboardShortcuts();
});
