from sqlalchemy import or_
from app.models import (
    Resident,
    Flat,
    MaintenanceBill,
    Complaint,
    Visitor,
    Vehicle,
    Notice,
    Payment,
    PaymentReceipt,
    Role,
)


class SearchService:
    @staticmethod
    def global_search(user, society_id, query_str):
        """
        Global search engine with role-aware privacy enforcement.
        Admins search society-wide records.
        Residents ONLY search their own bills, payments, receipts, complaints, visitors, and public notices.
        """
        if not query_str or len(query_str.strip()) < 2:
            return {"query": query_str, "categories": []}

        term = f"%{query_str.strip()}%"
        is_resident = user.role in ["Resident", Role.RESIDENT]

        categories = []

        if is_resident:
            # Find associated resident profile for logged-in resident user
            resident = Resident.query.filter_by(
                user_id=user.id, society_id=society_id
            ).first()

            if not resident:
                return {"query": query_str, "categories": []}

            # 1. Own Bills
            own_bills = (
                MaintenanceBill.query.filter_by(society_id=society_id, resident_id=resident.id)
                .filter(
                    (MaintenanceBill.bill_number.ilike(term))
                    | (MaintenanceBill.billing_month.ilike(term))
                )
                .limit(5)
                .all()
            )
            if own_bills:
                categories.append({
                    "key": "category_bills",
                    "items": [
                        {
                            "id": b.id,
                            "title": f"Bill #{b.bill_number} - {b.billing_month}",
                            "subtitle": f"Amount: ₹{b.total_amount} | Status: {b.status}",
                            "url": f"/resident/bill/{b.id}",
                            "icon": "fa-file-invoice"
                        }
                        for b in own_bills
                    ]
                })

            # 2. Own Payments & Receipts
            own_receipts = (
                PaymentReceipt.query.join(Payment)
                .filter(
                    Payment.resident_id == resident.id,
                    Payment.society_id == society_id,
                    PaymentReceipt.receipt_number.ilike(term),
                )
                .limit(5)
                .all()
            )
            if own_receipts:
                categories.append({
                    "key": "category_receipts",
                    "items": [
                        {
                            "id": r.id,
                            "title": f"Receipt #{r.receipt_number}",
                            "subtitle": f"Generated: {r.generated_at.strftime('%Y-%m-%d') if r.generated_at else ''}",
                            "url": f"/resident/receipt/{r.id}",
                            "icon": "fa-receipt"
                        }
                        for r in own_receipts
                    ]
                })

            # 3. Own Complaints
            own_complaints = (
                Complaint.query.filter_by(society_id=society_id, resident_id=resident.id)
                .filter(
                    (Complaint.ticket_number.ilike(term)) | (Complaint.title.ilike(term))
                )
                .limit(5)
                .all()
            )
            if own_complaints:
                categories.append({
                    "key": "category_complaints",
                    "items": [
                        {
                            "id": c.id,
                            "title": f"#{c.ticket_number} - {c.title}",
                            "subtitle": f"Status: {c.status}",
                            "url": f"/complaints/list",
                            "icon": "fa-headset"
                        }
                        for c in own_complaints
                    ]
                })

            # 4. Own Visitors
            own_visitors = (
                Visitor.query.filter_by(society_id=society_id, resident_id=resident.id)
                .filter(
                    (Visitor.visitor_name.ilike(term)) | (Visitor.mobile.ilike(term)) | (Visitor.purpose.ilike(term))
                )
                .limit(5)
                .all()
            )
            if own_visitors:
                categories.append({
                    "key": "category_visitors",
                    "items": [
                        {
                            "id": v.id,
                            "title": f"Visitor: {v.visitor_name}",
                            "subtitle": f"Purpose: {v.purpose or '-'}",
                            "url": f"/visitors/list",
                            "icon": "fa-id-badge"
                        }
                        for v in own_visitors
                    ]
                })

            # 5. Public Notices / Announcements
            notices = (
                Notice.query.filter_by(society_id=society_id)
                .filter(Notice.title.ilike(term) | Notice.content.ilike(term))
                .limit(5)
                .all()
            )
            if notices:
                categories.append({
                    "key": "category_notices",
                    "items": [
                        {
                            "id": n.id,
                            "title": n.title,
                            "subtitle": f"Notice | Type: {n.notice_type}",
                            "url": "/resident/announcements",
                            "icon": "fa-bullhorn"
                        }
                        for n in notices
                    ]
                })

        else:
            # ADMIN SEARCH (Super Admin, Society Admin, Accounting Staff, Security Staff)

            # 1. Residents
            residents = (
                Resident.query.filter_by(society_id=society_id)
                .filter((Resident.full_name.ilike(term)) | (Resident.mobile.ilike(term)) | (Resident.email.ilike(term)))
                .limit(5)
                .all()
            )
            if residents:
                categories.append({
                    "key": "category_residents",
                    "items": [
                        {
                            "id": r.id,
                            "title": r.full_name,
                            "subtitle": f"Mobile: {r.mobile or '-'} | Type: {r.resident_type}",
                            "url": "/admin/residents",
                            "icon": "fa-user"
                        }
                        for r in residents
                    ]
                })

            # 2. Flats
            flats = (
                Flat.query.filter_by(society_id=society_id)
                .filter(Flat.flat_number.ilike(term))
                .limit(5)
                .all()
            )
            if flats:
                categories.append({
                    "key": "category_flats",
                    "items": [
                        {
                            "id": f.id,
                            "title": f"Flat {f.flat_number}",
                            "subtitle": f"Floor: {f.floor_number} | Occupancy: {f.occupancy_status}",
                            "url": "/admin/flats",
                            "icon": "fa-building"
                        }
                        for f in flats
                    ]
                })

            # 3. Bills
            bills = (
                MaintenanceBill.query.filter_by(society_id=society_id)
                .filter(
                    (MaintenanceBill.bill_number.ilike(term))
                    | (MaintenanceBill.billing_month.ilike(term))
                )
                .limit(5)
                .all()
            )
            if bills:
                categories.append({
                    "key": "category_bills",
                    "items": [
                        {
                            "id": b.id,
                            "title": f"Bill #{b.bill_number} - {b.billing_month}",
                            "subtitle": f"Amount: ₹{b.total_amount} | Status: {b.status}",
                            "url": "/payments/bills",
                            "icon": "fa-file-invoice"
                        }
                        for b in bills
                    ]
                })

            # 4. Payments & Receipts
            payments = (
                Payment.query.filter_by(society_id=society_id)
                .filter(
                    (Payment.transaction_id.ilike(term)) | (Payment.payment_method.ilike(term))
                )
                .limit(5)
                .all()
            )
            if payments:
                categories.append({
                    "key": "category_payments",
                    "items": [
                        {
                            "id": p.id,
                            "title": f"Payment TXN #{p.transaction_id}",
                            "subtitle": f"Paid: ₹{p.amount_paid} via {p.payment_method} ({p.status})",
                            "url": "/payments/bills",
                            "icon": "fa-receipt"
                        }
                        for p in payments
                    ]
                })

            # 5. Complaints
            complaints = (
                Complaint.query.filter_by(society_id=society_id)
                .filter(
                    (Complaint.ticket_number.ilike(term)) | (Complaint.title.ilike(term))
                )
                .limit(5)
                .all()
            )
            if complaints:
                categories.append({
                    "key": "category_complaints",
                    "items": [
                        {
                            "id": c.id,
                            "title": f"#{c.ticket_number} - {c.title}",
                            "subtitle": f"Status: {c.status}",
                            "url": "/complaints/list",
                            "icon": "fa-headset"
                        }
                        for c in complaints
                    ]
                })

            # 6. Visitors
            visitors = (
                Visitor.query.filter_by(society_id=society_id)
                .filter((Visitor.visitor_name.ilike(term)) | (Visitor.mobile.ilike(term)))
                .limit(5)
                .all()
            )
            if visitors:
                categories.append({
                    "key": "category_visitors",
                    "items": [
                        {
                            "id": v.id,
                            "title": f"Visitor: {v.visitor_name}",
                            "subtitle": f"Mobile: {v.mobile or '-'} | Purpose: {v.purpose or '-'}",
                            "url": "/visitors/list",
                            "icon": "fa-id-badge"
                        }
                        for v in visitors
                    ]
                })

            # 7. Vehicles
            vehicles = (
                Vehicle.query.filter_by(society_id=society_id)
                .filter(Vehicle.vehicle_number.ilike(term))
                .limit(5)
                .all()
            )
            if vehicles:
                categories.append({
                    "key": "category_vehicles",
                    "items": [
                        {
                            "id": v.id,
                            "title": f"Vehicle #{v.vehicle_number}",
                            "subtitle": f"Type: {v.vehicle_type}",
                            "url": "/visitors/list",
                            "icon": "fa-car"
                        }
                        for v in vehicles
                    ]
                })

        return {"query": query_str, "categories": categories}
